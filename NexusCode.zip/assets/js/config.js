export const API_URL = 'https://api.nexuscodebrasil.com.br/api/v1';
